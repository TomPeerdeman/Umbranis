Ramses IJff - 10183043
René Aparicio Saez - 10214054
Tom Peerdeman - 10266186
Sidney Monk - 10283099

~~~~~~~~~~~~~~~~~~

URL:

umbranis.nl
www.umbranis.nl
websec.science.uva.nl/webdb1242

~~~~~~~~~~~~~~~~~~

Admin account voor de website:

Gebruikersnaam: admin
Password: welkom

~~~~~~~~~~~~~~~~~~

Niet eigen code:

Twitterfeed:

<script src="http://widgets.twimg.com/j/2/widget.js" type="text/javascript"></script>

<script type="text/javascript">
	new TWTR.Widget({
	  version: 2,
	  type: 'profile',
	  rpp: 4,
	  interval: 30000,
	  width: 164,
	  height: 180,
	  theme: {
		shell: {
		  background: '#333333',
		  color: '#ffffff'
		},
		tweets: {
		  background: '#000000',
		  color: '#ffffff',
		  links: '#F8D50C'
		}
	  },
	  features: {
		scrollbar: true,
		loop: false,
		live: false,
		behavior: 'all'
	  }
	}).render().setUser('Umbranis').start();
</script>

~~~~~~~~~~~~~~~~~~