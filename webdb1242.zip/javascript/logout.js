function init(){
	setTimeout(function(){
		window.location.href = '?p=home';
	}, 6000);
}